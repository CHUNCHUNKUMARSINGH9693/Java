public class Q4 {
    public static void main(String[] args) {
        int[][] values = {
            {72, 5},
            {345, 10},
            {345, 100}
        };

        for (int i = 0; i < values.length; i++) {
            int dividend = values[i][0];
            int divisor = values[i][1];
            int quotient = dividend / divisor;
            int remainder = dividend % divisor;
            System.out.println("Dividend: " + dividend + ", Divisor: " + divisor);
            System.out.println("Quotient: " + quotient);
            System.out.println("Remainder: " + remainder);
        }
    }
}

