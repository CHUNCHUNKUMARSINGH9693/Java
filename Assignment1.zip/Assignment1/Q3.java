import java.util.Scanner;

public class Q3 {
        public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int mark1, mark2, mark3;
        System.out.print("Enter the first mark: ");
        mark1 = scanner.nextInt();

        System.out.print("Enter the second mark: ");
        mark2 = scanner.nextInt();

        System.out.print("Enter the third mark: ");
        mark3 = scanner.nextInt();

        int sum = mark1 + mark2 + mark3;
        int average = sum / 3;

        System.out.println("Sum of marks: " + sum);
        System.out.println("Average of marks: " + average);
        scanner.close();
    }
}

