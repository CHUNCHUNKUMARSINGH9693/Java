public class Q2 {    
        public static void main(String[] args) {
       
        int C = 10;
        int D = 20;
        System.out.println("Before Interchange:");
        System.out.println("C = " + C);
        System.out.println("D = " + D);

        int temp = C; 
        C = D;       
        D = temp;    
        System.out.println("After Interchange:");
        System.out.println("C = " + C);
        System.out.println("D = " + D);
    }
}