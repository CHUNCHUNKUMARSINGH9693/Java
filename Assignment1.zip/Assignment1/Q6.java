import java.util.Scanner;

public class Q6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the side length of the square (int): ");
        int side = scanner.nextInt();
        
        int squareArea = side * side;
        int squarePerimeter = 4 * side;
        System.out.println("Square Area: " + squareArea);
        System.out.println("Square Perimeter: " + squarePerimeter);
        System.out.print("Enter the length of the rectangle (int): ");
        int length = scanner.nextInt();
        
        System.out.print("Enter the breadth of the rectangle (int): ");
        int breadth = scanner.nextInt();
        
        int rectangleArea = length * breadth;
        int rectanglePerimeter = 2 * (length + breadth);
        System.out.println("Rectangle Area: " + rectangleArea);
        System.out.println("Rectangle Perimeter: " + rectanglePerimeter);
        scanner.close();
    }
}
    

