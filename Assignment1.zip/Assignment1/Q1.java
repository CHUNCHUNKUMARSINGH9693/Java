public class Q1 {
    public static void main(String[] args) {
        
        int intValue = 42;                    
        double doubleValue = 3.14;            
        char charValue = 'A';                  
        boolean booleanValue = true;           
        String stringValue = "Hello, World!"; 
        float floatValue = 2.5f;               
        long longValue = 100000L;              
        byte byteValue = 100;                  
        short shortValue = 30000;              

        System.out.println("Integer Value: " + intValue);
        System.out.println("Double Value: " + doubleValue);
        System.out.println("Character Value: " + charValue);
        System.out.println("Boolean Value: " + booleanValue);
        System.out.println("String Value: " + stringValue);
        System.out.println("Float Value: " + floatValue);
        System.out.println("Long Value: " + longValue);
        System.out.println("Byte Value: " + byteValue);
        System.out.println("Short Value: " + shortValue);
    }
}