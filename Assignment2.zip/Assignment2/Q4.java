public class Q4 {
    public static void main(String[] args) {
        int condition1 = (4 > 7) ? 0 : 1;
        int condition2 = (10 > 5) ? 0 : 1; 

        boolean cond1 = condition1 != 0; 
        boolean cond2 = condition2 != 0; 

        boolean andResult = cond1 && cond2;
        boolean orResult = cond1 || cond2;
        boolean notCond1 = !cond1;
        boolean notCond2 = !cond2;

        System.out.println("Comparing conditions:");
        System.out.println("4 > 7 : " + cond1); // false
        System.out.println("10 > 5 : " + cond2); // true
        System.out.println("cond1 && cond2 : " + andResult);
        System.out.println("cond1 || cond2 : " + orResult);
        System.out.println("cond1 : " + notCond1);
        System.out.println("cond2 : " + notCond2);
    }
}
