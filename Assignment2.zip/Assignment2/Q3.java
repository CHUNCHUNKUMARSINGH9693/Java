import java.util.Scanner;

public class Q3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the first Boolean value");
        int bool1 = scanner.nextInt();

        System.out.print("Enter the second Boolean value");
        int bool2 = scanner.nextInt();
        boolean value1 = bool1 != 0; 
        boolean value2 = bool2 != 0; 
        boolean andResult = value1 && value2;
        boolean orResult = value1 || value2;
        boolean notValue1 = !value1;
        boolean notValue2 = !value2;
        System.out.println("Using logical operators:");
        System.out.println("value1 && value2 : " + andResult);
        System.out.println("value1 || value2 : " + orResult);
        System.out.println("value1 : " + notValue1);
        System.out.println("value2 : " + notValue2);
        scanner.close();
    }
}
