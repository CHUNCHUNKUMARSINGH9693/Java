import java.util.Scanner;

public class Q4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter an integer: ");
        int number = scanner.nextInt();

        if (number > 7) {
            System.out.println(number + " is greater than 7.");
        } else if (number < 7) {
            System.out.println(number + " is less than 7.");
        } else {
            System.out.println(number + " is equal to 7.");
        }
        scanner.close();
    }
}
