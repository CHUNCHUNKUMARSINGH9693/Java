import java.util.Scanner;
public class Q2 {
       public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the value of C: ");
        int C = scanner.nextInt();

        System.out.print("Enter the value of D: ");
        int D = scanner.nextInt();
        
        System.out.println("Before interchange: C = " + C + ", D = " + D);
        
        C = C + D; 
        D = C - D; 
        C = C - D; 
        System.out.println("After interchange: C = " + C + ", D = " + D);
        scanner.close();
    }
}

