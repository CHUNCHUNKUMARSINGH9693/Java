import java.util.Scanner;

public class Q4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the side length of the cube: ");
        double side = scanner.nextDouble();
        double volumeCube = Math.pow(side, 3);
        System.out.printf("Volume of the cube: %.2f%n", volumeCube);

        System.out.print("Enter the length of the cuboid: ");
        double length = scanner.nextDouble();
        System.out.print("Enter the width of the cuboid: ");
        double width = scanner.nextDouble();
        System.out.print("Enter the height of the cuboid: ");
        double height = scanner.nextDouble();
        double volumeCuboid = length * width * height;
        System.out.printf("Volume of the cuboid: %.2f%n", volumeCuboid);

        System.out.print("Enter the radius of the cone: ");
        double radiusCone = scanner.nextDouble();
        System.out.print("Enter the height of the cone: ");
        double heightCone = scanner.nextDouble();
        double volumeCone = (1.0 / 3) * Math.PI * Math.pow(radiusCone, 2) * heightCone;
        System.out.printf("Volume of the cone: %.2f%n", volumeCone);

        System.out.print("Enter the radius of the cylinder: ");
        double radiusCylinder = scanner.nextDouble();
        System.out.print("Enter the height of the cylinder: ");
        double heightCylinder = scanner.nextDouble();
        double volumeCylinder = Math.PI * Math.pow(radiusCylinder, 2) * heightCylinder;
        System.out.printf("Volume of the cylinder: %.2f%n", volumeCylinder);

        System.out.print("Enter the radius of the sphere: ");
        double radiusSphere = scanner.nextDouble();
        double volumeSphere = (4.0 / 3) * Math.PI * Math.pow(radiusSphere, 3);
        System.out.printf("Volume of the sphere: %.2f%n", volumeSphere);
        scanner.close();
    }
}