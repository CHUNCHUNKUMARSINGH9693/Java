import java.util.Scanner;

public class Q3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the principal amount: ");
        double principal = scanner.nextDouble();
        
        System.out.print("Enter the rate of interest (in %): ");
        double rateOfInterest = scanner.nextDouble();
        System.out.print("Enter the number of years: ");
        int years = scanner.nextInt();
        
        //calcualte Simple Interest
        double simpleInterest = (principal * rateOfInterest * years) / 100;
        
        // Calculate Compound Interest
        double compoundInterest = principal * Math.pow((1 + rateOfInterest / 100), years) - principal;
        
        
        System.out.printf("Simple Interest: %.2f%n", simpleInterest);
        System.out.printf("Compound Interest: %.2f%n", compoundInterest);
        scanner.close();
    }
}
