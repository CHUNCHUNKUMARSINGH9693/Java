import java.util.Scanner;

public class Q5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the original price of the product: ");
        double originalPrice = scanner.nextDouble();
        
        double discount = originalPrice * 0.10;  
        double finalPrice = originalPrice - discount;  
        System.out.printf("Original Price: %.2f%n", originalPrice);
        System.out.printf("Discount (10%%): %.2f%n ", discount);
        System.out.printf("Price after discount: %.2f%n ", finalPrice);
        scanner.close();
    }
}
